from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from ExpenditureApp.models import Transaction, Expense
from django.http.response import JsonResponse
from ExpenditureApp.serializers import TransactionSerializer, ExpenseSerializer


# Create your views here.

# making the transaction API
@csrf_exempt
def transactionApi(request, id = 0):
    
    # API for GET method to receive the data
    if request.method == 'GET':
        transactions = Transaction.objects.all()
        transactions_serializer = TransactionSerializer(transactions, many = True)
        return JsonResponse(transactions_serializer.data, safe = False)
      
    # API for POST method to send the data to the database (SQLite)    
    elif request.method == 'POST':
        transaction_data = JSONParser().parse(request)
        transaction_serializer = TransactionSerializer(data = transaction_data)
        if(transaction_serializer.is_valid()):
            transaction_serializer.save()
            
            return JsonResponse("Added Successfully", safe=False)
        
        return JsonResponse("Failed to add", safe=False)
    
    # API for PUT method to update the data in the database (SQLite)    
    elif request.method == 'PUT':
        transaction_data = JSONParser().parse(request)
        transaction = Transaction.objects.get(TransactionId = transaction_data['TransactionId'])
        transaction_serializer = TransactionSerializer(transaction, data = transaction_data)
        
        if transaction_serializer.is_valid():
            transaction_serializer.save()
            return JsonResponse("Updated Successfully", safe=False)
        
        return JsonResponse("Failed to update", safe=False)
    
    # API for DELET method to delete the data from the database (SQLite)   
    #there is some bug in the delete method so delete operations cannot be performed for now
    elif request.method == 'DELETE':
        transaction = Transaction.objects.get(TransactionId = id)
        transaction.delete()
        return JsonResponse("Deleted successfully", safe=False)
    
@csrf_exempt
def expenseApi(request, id = 0):
    if request.method == 'GET':
        expenses = Expense.objects.all()
        expenses_serializer = ExpenseSerializer(expenses, many = True)
        return JsonResponse(expenses_serializer.data, safe = False)
        
    elif request.method == 'POST':
        expense_data = JSONParser().parse(request)
        expense_serializer = ExpenseSerializer(data = expense_data)
        if(expense_serializer.is_valid()):
            expense_serializer.save()
            
            return JsonResponse("Added Successfully", safe=False)
        
        return JsonResponse("Failed to add", safe=False)
    
    elif request.method == 'PUT':
        expense_data = JSONParser().parse(request)
        expense = Expense.objects.get(ExpenseId = expense_data['ExpenseId'])
        expense_serializer = ExpenseSerializer(expense, data = expense_data)
        
        if expense_serializer.is_valid():
            expense_serializer.save()
            return JsonResponse("Updated Successfully", safe=False)
        
        return JsonResponse("Failed to update", safe=False)
    
    elif request.method == 'DELETE':
        expense = Expense.objects.get(ExpenseId = id)
        expense.delete()
        return JsonResponse("Deleted successfully", safe=False)