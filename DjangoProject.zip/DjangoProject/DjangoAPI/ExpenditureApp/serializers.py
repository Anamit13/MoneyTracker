from rest_framework import serializers

from ExpenditureApp.models import Transaction, Expense

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = ('TransactionId', 'TransactionType')
        
        
class ExpenseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Expense
        fields = ('ExpenseId',
                  'ExpenseAmt',
                  'ExpenseType',
                  'ExpenseSplit',
                  'ExpenseDate',
                  'ExpenseCat',
                  'ExpenseStatus')
        