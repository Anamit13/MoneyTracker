from django.urls import re_path as url
from ExpenditureApp import views 

urlpatterns = [
    url(r'^transaction/$', views.transactionApi), 
    url(r'^transaction/([0-9]+)$', views.transactionApi),
    url(r'^expense/$', views.expenseApi), 
    url(r'^expense/([0-9]+)$', views.expenseApi)
]