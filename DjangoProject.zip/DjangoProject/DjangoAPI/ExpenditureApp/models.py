from django.db import models

# Create your models here.
class Transaction(models.Model):
    TransactionId = models.AutoField(primary_key=True)
    TransactionType = models.CharField(max_length=50)

class Expense(models.Model):
    ExpenseId = models.AutoField(primary_key=True)
    ExpenseAmt = models.IntegerField()
    ExpenseType = models.CharField(max_length=50)
    ExpenseSplit = models.IntegerField()
    ExpenseDate = models.DateField()
    ExpenseCat = models.CharField(max_length=50)
    ExpenseStatus = models.CharField(max_length=50)