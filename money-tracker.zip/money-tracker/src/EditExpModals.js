import React,{Component} from 'react';
import {Modal,Button, Row, Col, Form} from 'react-bootstrap';

export class EditExpModals extends Component{
    constructor(props){
        super(props);
        this.state = {trans:[]};
        this.handleSubmit=this.handleSubmit.bind(this);
    }

    componentDidMount(){
        fetch(process.env.REACT_APP_API+"transaction")
        .then(response=>response.json())
        .then(data=>{
            this.setState({trans:data});
        }); 
    }

    handleSubmit(event){
        event.preventDefault();
        fetch(process.env.REACT_APP_API+"expense"+"/",{
            method:'PUT',
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                ExpenseId:event.target.ExpenseId.value,
                ExpenseAmt:event.target.ExpenseAmt.value,
                ExpenseType:event.target.ExpenseType.value,
                ExpenseSplit:event.target.ExpenseSplit.value,
                ExpenseDate:event.target.ExpenseDate.value,
                ExpenseCat:event.target.ExpenseCat.value,
                ExpenseStatus:event.target.ExpenseStatus.value
            })
        })
        .then(res=>res.json())
        .then((result)=>{
            alert(result);
        },
        (error)=>{
            alert('Failed');
        })
    }
    render(){
        return (
            <div className="container">

<Modal
{...this.props}
size="lg"
aria-labelledby="contained-modal-title-vcenter"
centered
>
    <Modal.Header clooseButton>
        <Modal.Title id="contained-modal-title-vcenter">
            Edit
        </Modal.Title>
    </Modal.Header>
    <Modal.Body>

        <Row>
            <Col sm={6}>
                <Form onSubmit={this.handleSubmit}>
                <Form.Group controlId="ExpenseId">
                        <Form.Label>Expense ID</Form.Label>
                        <Form.Control type="text" name="ExpenseId" required
                        disabled
                        defaultValue={this.props.expenseid} 
                        placeholder="Expense ID"/>
                    </Form.Group>

                    <Form.Group controlId="ExpenseAmt">
                        <Form.Label>Expense Amount</Form.Label>
                        <Form.Control type="text" name="ExpenseAmt" required 
                        placeholder="Expense Amount"/>
                    </Form.Group>
                    
                    <Form.Group controlId="ExpenseType">
                        <Form.Label>Expense Type</Form.Label>
                        <Form.Control as="select">
                        {this.state.trans.map(dep=>
                            <option key={dep.TransactionId}>{dep.TransactionType}</option>)}
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="ExpenseSplit">
                        <Form.Label>Expense Split</Form.Label>
                        <Form.Control type="text" name="ExpenseSplit" required 
                        placeholder="Expense Split"/>
                    </Form.Group>

                    <Form.Group controlId="ExpenseDate">
                        <Form.Label>Expense Date</Form.Label>
                        <Form.Control 
                        type="date"
                        name="ExpenseDate"
                        required
                        placeholder="Expense Date"/>
                    
                        
                    </Form.Group>

                    <Form.Group controlId="ExpenseCat">
                        <Form.Label>Expense Category</Form.Label>
                        <Form.Control type="text" name="ExpenseCat" required 
                        placeholder="Expense Category"/>
                    </Form.Group>

                    <Form.Group controlId="ExpenseStatus">
                        <Form.Label>Expense Status</Form.Label>
                        <Form.Control type="text" name="ExpenseStatus" required 
                        placeholder="Expense Status"/>
                    </Form.Group>
                    <br></br>

                    <Form.Group>
                        <Button variant="success" type="submit">
                            Update Expense
                        </Button>
                    </Form.Group>
                </Form>
            </Col>
        </Row>
    </Modal.Body>
    
    <Modal.Footer>
        <Button variant="danger" onClick={this.props.onHide}>Close</Button>
    </Modal.Footer>

</Modal>

            </div>
        )
    }

}