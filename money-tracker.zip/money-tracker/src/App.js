import './App.css';

import {Home} from './Home';
import {Transaction} from './Transaction';
import {Expense} from './Expense';
import {Navigation} from './Navigation';

import {BrowserRouter, Route, Routes} from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
    
      <div className="container">
        <h3 className='m-3 d-flex justify-content-center'>
          Money Tracker
        </h3>
        
        <Navigation/>

        <Routes>
          <Route path='/' element = {<Home/>} exact/>
          <Route path='/transaction' element = {<Transaction/>} />
          <Route path='/expense' element = {<Expense/>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
