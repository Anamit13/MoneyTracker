import React, {Component} from "react";
import {Table} from 'react-bootstrap';

import {Button,ButtonToolbar} from 'react-bootstrap';
import {AddTraModals} from './AddTraModals';
import {EditTraModals} from './EditTraModals';

export class Transaction extends Component{

    constructor(props){
        super(props);
        this.state = {trans:[]}
    }

    refreshList(){
        console.log(process.env.REACT_APP_API+"transaction");
        fetch(process.env.REACT_APP_API+"transaction")
        .then(response=>response.json())
        .then(data=>{
            this.setState({trans:data});
        });
    }

    componentDidMount(){
        this.refreshList(); 
    }

    componentDidUpdate(){
        this.refreshList();
    }

    render(){
        const {trans, traid,tratype}=this.state;
        let addModalClose=()=>this.setState({addModalShow:false});
        let editModalClose=()=>this.setState({editModalShow:false});
        return(
            <div>
                <Table className="mt-4" striped bordered hover size = 'sm' variant = 'light'>
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Transaction Type</th>
                            <th>Action</th>
                        </tr>
                        
                    </thead>

                    <tbody>
                        {trans.map(tra=> 
                            <tr key={tra.TransactionId}>
                                
                                <td>{tra.TransactionId}</td>
                                <td>{tra.TransactionType}</td>
                                <td>
                                {/* Code for edit button  */}
                                <ButtonToolbar>
                                    <Button className="mr-2" variant="outline-warning"
                                    onClick={()=>this.setState({editModalShow:true,
                                        traid:tra.TransactionId,tratype:tra.TransactionType})}>
                                            Edit
                                        </Button>


                                        <EditTraModals show={this.state.editModalShow}
                                        onHide={editModalClose}
                                        traid={traid}
                                        tratype={tratype}/>
                                </ButtonToolbar>

                                </td>

                            </tr>)}
                    </tbody>

                </Table>
                <ButtonToolbar>
                    <Button variant='outline-secondary'
                    onClick={()=>this.setState({addModalShow:true})}>
                    Add Transaction Type</Button>

                    <AddTraModals show={this.state.addModalShow}
                    onHide={addModalClose}/>
                </ButtonToolbar>
            </div>
        )
        
    }
}
