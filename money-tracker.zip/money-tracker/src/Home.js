import React, {Component} from "react";

export class Home extends Component{

    render(){
        return(
            <div className="align-baseline">
                <br></br>
                <h2>Smart Money Tracker</h2>
                <br></br>
                <h5>This is the home page of the application and in the top navigation you can see two more 
                    options of TRANSACTION TYPE and EXPENSES. Below is the process to use it.
                </h5>
                <br></br>
                <ul>
                    <li>In transaction type you can add any transaction type like individual, group, self, other, etc</li>
                    <li>You can also edit the particular transaction type in any situation</li>
                    <li>In the expenses part you add following details of expenses
                        <ul>
                            <li>Expense Amount</li>
                            <li>Expense type from the transaction type list</li>
                            <li>The split amount in case you paid for others as well</li>
                            <li>Expense date</li>
                            <li>Category like food, taxi, etc.</li>
                            <li>Status like the expense is paid or still unpaid</li>
                        </ul>
                    </li>
                    <li>You can also edit any particular expense in case of any mistake</li>
                </ul>
            </div>
        )
        
    }
}