import React, {Component} from "react";
import {Table} from 'react-bootstrap';

import {Button,ButtonToolbar} from 'react-bootstrap';
import {AddExpModals} from './AddExpModals';
import {EditExpModals} from './EditExpModals';

export class Expense extends Component{

    constructor(props){
        super(props);
        this.state = {expen:[]}
    }

    refreshList(){
        
        fetch(process.env.REACT_APP_API+"expense")
        .then(response=>response.json())
        .then(data=>{
            this.setState({expen:data});
        });
    }

    componentDidMount(){
        this.refreshList(); 
    }

    componentDidUpdate(){
        this.refreshList();
    }

    render(){
        const {expen, expenseid,expenseamt, expensetype, expensesplit, expensedate, expensecat, expensestatus}=this.state;
        let addModalClose=()=>this.setState({addModalShow:false});
        let editModalClose=()=>this.setState({editModalShow:false});
        return(
            <div>
                <Table className="mt-4" striped bordered hover size = 'sm' variant = 'light'>
                    <thead>
                        <tr>
                            <th>Expense ID</th>
                            <th>Expense Amount</th>
                            <th>Expense Type</th>
                            <th>Expense Split</th>
                            <th>Expense Date</th>
                            <th>Expense Category</th>
                            <th>Expense Status</th>
                            <th>Action</th>
                        </tr>
                        
                    </thead>

                    <tbody>
                        {expen.map(exp=> 
                            <tr key={exp.ExpenseId}>
                                
                                <td>{exp.ExpenseId}</td>
                                <td>{exp.ExpenseAmt}</td>
                                <td>{exp.ExpenseType}</td>
                                <td>{exp.ExpenseSplit}</td>
                                <td>{exp.ExpenseDate}</td>
                                <td>{exp.ExpenseCat}</td>
                                <td>{exp.ExpenseStatus}</td>
                                <td>
                                {/* Code for edit button  */}
                                <ButtonToolbar>
                                    <Button className="mr-2" variant="outline-warning"
                                    onClick={()=>this.setState({editModalShow:true,
                                        expenseid:exp.ExpenseId,expenseamt:exp.ExpenseAmt,expensetype:exp.ExpenseType,expensesplit:exp.ExpenseSplit,expensedate:exp.ExpenseDate,expensecat:exp.ExpenseCat,expensestatus:exp.ExpenseStatus})}>
                                            Edit
                                        </Button>


                                        <EditExpModals show={this.state.editModalShow}
                                        onHide={editModalClose}
                                        expenseid={expenseid}
                                        expenseamt={expenseamt}
                                        expensetype={expensetype}
                                        expensesplit={expensesplit}
                                        expensedate={expensedate}
                                        expensecat={expensecat}
                                        expensestatus={expensestatus}/>
                                </ButtonToolbar>

                                </td>

                            </tr>)}
                    </tbody>

                </Table>
                <ButtonToolbar>
                    <Button variant='outline-secondary'
                    onClick={()=>this.setState({addModalShow:true})}>
                    Add Transaction Type</Button>

                    <AddExpModals show={this.state.addModalShow}
                    onHide={addModalClose}/>
                </ButtonToolbar>
            </div>
        )
        
    }
}
